package com.example.praktikan.jurnal4;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class LangkaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ternak);

        ArrayList<String> data =new ArrayList<>();
        data.add("Anoa");
        data.add("Bekantan");
        data.add("Burung Jalak Bali");
        data.add("Burung Enggang Gading");
        data.add("Burung Maleo Senkawor");
        data.add("Burung Mandar Dengkur");
        data.add("Mentilin");
        data.add("Ikan Pesut Mahakam");
        data.add("Rusa Timor");
        data.add("Tangkasi");

        ListView listView = findViewById(R.id.word_list);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, data);
        listView.setAdapter(adapter);
    }
}
