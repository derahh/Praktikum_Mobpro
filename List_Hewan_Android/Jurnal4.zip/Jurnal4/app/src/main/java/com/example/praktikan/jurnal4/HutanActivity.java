package com.example.praktikan.jurnal4;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class HutanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ternak);

        ArrayList<String> data =new ArrayList<>();
        data.add("Berang-Berang");
        data.add("Katak");
        data.add("Koala");
        data.add("Kudanil");
        data.add("Laba-laba");
        data.add("Landak");
        data.add("Monyet");
        data.add("Rakun");
        data.add("Rubah");
        data.add("Tapir");

        ListView listView = findViewById(R.id.word_list);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, data);
        listView.setAdapter(adapter);
    }
}
