package com.example.praktikan.jurnal4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class TernakActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ternak);

        ArrayList<String> data =new ArrayList<>();
        data.add("Angsa");
        data.add("Ayam");
        data.add("Bebek");
        data.add("Domba");
        data.add("Kalkun");
        data.add("Kambing");
        data.add("Kelinci");
        data.add("Kerbau");
        data.add("Kuda");
        data.add("Sapi");

        ListView listView = findViewById(R.id.word_list);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, data);
        listView.setAdapter(adapter);
    }
}
